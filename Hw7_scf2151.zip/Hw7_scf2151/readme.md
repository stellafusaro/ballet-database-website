You must have flask installed to run this application

Tun this code in the terminal with 
python server.py
or
python3 server.py (depending on your python installation)

The terminal will give you a URL to go to, probably this
http://127.0.0.1:5001


You should see things!

If you need to stop running the Flask application, go back to the terminal, and press Ctrl+C
